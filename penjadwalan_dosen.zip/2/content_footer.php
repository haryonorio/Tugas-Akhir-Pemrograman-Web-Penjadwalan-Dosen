<footer class="main-footer">
    <div class="pull-right hidden-xs"></div>
    <strong>Copyright &copy; <?php echo date("Y") ?> IDS Akademik and Created By <a href="https://www.facebook.com/derryikhsan.sholahuddin1">Derry Ikhsan</a></strong>
</footer>